﻿using System;
namespace Game
{
    public interface IRunner
    {
        void RunGame();
    }
}
